using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class test : MonoBehaviour, IPointerClickHandler
{
	public TextMeshProUGUI pTextMeshPro;
	public void OnPointerClick(PointerEventData eventData)
	{
		int linkIndex = TMP_TextUtilities.FindIntersectingLink(pTextMeshPro, Input.mousePosition, Camera.current);
		if (linkIndex == -1) return;
		TMP_LinkInfo linkInfo = pTextMeshPro.textInfo.linkInfo[linkIndex];
		//Application.OpenURL(linkInfo.GetLinkID());
		Debug.Log(linkInfo.GetLinkID());
	}
}