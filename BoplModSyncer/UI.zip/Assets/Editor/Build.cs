using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine.UIElements;

class ListWrapper<T> : UnityEngine.Object
{
	public List<T> objects = new List<T>();
}

public class Build : EditorWindow
{
	[MenuItem("Build/Build prefabs")]
	static void Init()
	{
		Build window = CreateInstance<Build>();
		window.position = new Rect(Screen.width / 2, Screen.height / 2, Screen.width / 2, Screen.height / 2);
		window.ShowPopup();
	}

	public GameObject[] prefabs;

	private void OnGUI()
	{
		ScriptableObject target = this;
		SerializedObject so = new SerializedObject(target);

		RectOffset padding = new RectOffset(0, 0, 45, 0);
		Rect area = new Rect(padding.right, padding.top, position.width - (padding.right + padding.left), position.height - (padding.top + padding.bottom));

		GUILayout.BeginArea(area);
		DropAreaGUI(so);

		SerializedProperty property = so.FindProperty("prefabs");
		EditorGUILayout.PropertyField(property, true);
		so.ApplyModifiedProperties();

		GUILayout.EndArea();
	}

	void CreateGUI()
	{
		var div = new VisualElement();
		div.style.flexDirection = FlexDirection.Row;
		rootVisualElement.Add(div);

		var input = new TextField();
		input.value = "PanelBundle";
		rootVisualElement.Add(input);

		var okButton = new Button();
		okButton.text = "Ok";
		okButton.style.flexGrow = 1;
		okButton.clicked += () =>
		{
			if(prefabs != null && prefabs.Length != 0)
			{
				List<AssetBundleBuild> assets = new List<AssetBundleBuild>();
				List<string> paths = new List<string>();
				for (int i = 0; i < prefabs.Length; i++)
				{
					GameObject item = prefabs[i];
					if (item == null)
					{
						Debug.LogError($"#{i} item was null - halting building");
						return;
					}
					paths.Add(GetPrefabPath(item));
				}

				AssetBundleBuild ab = new AssetBundleBuild
				{
					assetBundleName = input.value,
					assetNames = paths.ToArray()
				};
				assets.Add(ab);

				BuildABs(assets);
			}
			Close();
		};
		div.Add(okButton);

		var closeButton = new Button();
		closeButton.text = "Close";
		closeButton.style.flexGrow = 1;
		closeButton.clicked += Close;
		div.Add(closeButton);
	}

	public void DropAreaGUI(SerializedObject so)
	{
		Event evt = Event.current;
		Rect drop_area = GUILayoutUtility.GetRect(0.0f, 50.0f, GUILayout.ExpandWidth(true));
		GUI.Box(drop_area, "Drop prefabs here");

		switch (evt.type)
		{
			case EventType.DragUpdated:
			case EventType.DragPerform:
				if (!drop_area.Contains(evt.mousePosition)) return;

				DragAndDrop.visualMode = DragAndDropVisualMode.Copy;

				if (evt.type == EventType.DragPerform)
				{
					DragAndDrop.AcceptDrag();

					if(prefabs == null) prefabs = new GameObject[0];

					List<GameObject> objects = new List<GameObject>();
					for (int i = 0; i < DragAndDrop.objectReferences.Length; i++)
					{
						Object obj = DragAndDrop.objectReferences[i];
						if (prefabs.Contains(obj)) continue;
						objects.Add(obj as GameObject);
					}

					if (objects.Count == 0) break;

					int oldLength = prefabs.Length;
					System.Array.Resize(ref prefabs, prefabs.Length + objects.Count);
					for (int i = 0; i < objects.Count; i++)
					{
						prefabs[i + oldLength] = objects[i];
					}
				}
				break;
		}
	}

	private static string GetPrefabPath(GameObject go)
	{
		Object parentObject = PrefabUtility.FindPrefabRoot(go);
		return AssetDatabase.GetAssetPath(parentObject);
	}

	private static void BuildABs(List<AssetBundleBuild> assets)
	{
		//Debug.Log(string.Join(", ", Directory.EnumerateFiles("Assets/", "*.prefab")));		

		string dir = "Assets/ABs";
		if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
		Debug.Log(BuildPipeline.BuildAssetBundles(dir, assets.ToArray(), BuildAssetBundleOptions.None, BuildTarget.StandaloneWindows));
	}
}